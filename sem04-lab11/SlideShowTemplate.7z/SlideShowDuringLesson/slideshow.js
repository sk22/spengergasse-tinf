"use strict";


var imgPath = "img";
var thumbnails = ["01_thumb.jpg", "02_thumb.jpg", "03_thumb.jpg", "04_thumb.jpg"];
var images = ["01.jpg", "02.jpg", "03.jpg", "04.jpg"];
var imgElements = [];   // Speichert die DOM Elemente der vorgeladenen (großen) Bilder.
var currentImage = 0;   // Das aktuell anzuzeigende Bild

/**
 * Lädt die in images Angegebenen BIlder und zeigt die Vorschauleiste mit Bildern aus dem 
 * thumbnails Array an.
 */
function onLoad(previewContainer, imgContainer) {


}

/**
 * Zeigt ein bestimmtes Bild groß an.
 * @param {string} imgContainer Die ID des Containers des großen Bildes.
 * @param {number} imgNr Die Position im images Array, die angezeigt wird.
 */

function displayImage(imgContainer, imgNr) {


}

/**
 * Springt im Array eine bestimmte Anzahl an Bildern vor oder zurück.
 * @param {strimg} imgContainer Die ID des Containers des großen Bildes.
 * @param {number} offset Die Schrittweite. 1 ist ein Bild vor, -1 ist ein Bild zurück.
 */
function moveImage(imgContainer, offset) {

}